SCREENSHOTS FOLDER
==================

Drop your email design exports (PNG or JPG) here.

Recommended naming (matches the project data):

Case studies:
  house-of-stallion-1.png
  house-of-stallion-2.png
  house-of-stallion-3.png
  probate-1.png
  probate-2.png
  salon-1.png
  salon-2.png
  salon-3.png
  voltix-1.png
  butter-1.png
  roseaura-1.png
  roseaura-2.png

Design gallery:
  renew.png
  valeva.png
  la-luna.png
  nuarai.png
  inrama.png
  moomenn.png
  alwrld.png
  deepzeez.png
  above-normal.png
  premier-jerseys.png
  sa-note.png
  hos-design.png

Tips:
- Export from Figma at 2x for crisp display
- Aim for ~800–1200px wide for email previews
- After adding files, refresh the site — placeholders are replaced automatically on case study pages
