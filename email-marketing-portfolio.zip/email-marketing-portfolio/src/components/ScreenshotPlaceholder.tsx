import { ImageIcon } from "lucide-react";

type Props = {
  label?: string;
  aspect?: "email" | "wide" | "square";
  className?: string;
};

const aspectMap = {
  email: "aspect-[4/5]",
  wide: "aspect-[16/10]",
  square: "aspect-square",
};

/**
 * Drop real screenshots into /public/screenshots/
 * then replace this component with:
 * <img src="/screenshots/your-file.png" alt="..." className="w-full rounded-xl" />
 */
export function ScreenshotPlaceholder({
  label = "Email screenshot",
  aspect = "email",
  className = "",
}: Props) {
  return (
    <div
      className={`relative flex flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed border-border bg-card ${aspectMap[aspect]} ${className}`}
    >
      <div className="absolute inset-0 bg-[linear-gradient(135deg,transparent_40%,rgba(255,92,26,0.04)_50%,transparent_60%)]" />
      <div className="relative z-10 flex flex-col items-center gap-2 px-4 text-center">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10">
          <ImageIcon className="h-5 w-5 text-accent" />
        </div>
        <p className="text-sm font-medium text-muted">{label}</p>
        <p className="text-[11px] text-muted-2">
          Add image to /public/screenshots/
        </p>
      </div>
    </div>
  );
}
