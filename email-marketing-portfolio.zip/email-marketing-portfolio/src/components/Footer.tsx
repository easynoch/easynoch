import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto max-w-6xl px-6 py-14">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-[13px] font-bold text-white">
                EA
              </span>
              <span className="font-semibold tracking-tight">Enoch Adesina</span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted">
              Klaviyo Email Marketing Specialist for Shopify DTC brands.
              Flows, campaigns, deliverability, and revenue growth.
            </p>
            <p className="mt-3 text-sm font-medium text-accent">
              $12/hr · Top Rated on Upwork
            </p>
          </div>

          <div className="flex gap-14">
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-muted-2">
                Navigate
              </h4>
              <ul className="mt-3 space-y-2 text-sm">
                {[
                  { href: "/work", label: "Work" },
                  { href: "/results", label: "Results" },
                  { href: "/designs", label: "Designs" },
                  { href: "/about", label: "About" },
                  { href: "/contact", label: "Contact" },
                ].map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-muted hover:text-accent transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-muted-2">
                Connect
              </h4>
              <ul className="mt-3 space-y-2 text-sm">
                <li>
                  <a
                    href="https://wa.me/2348131475529"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted hover:text-accent transition-colors"
                  >
                    WhatsApp
                  </a>
                </li>
                <li>
                  <a
                    href="https://www.linkedin.com/in/adebare-enoch-950a29404/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted hover:text-accent transition-colors"
                  >
                    LinkedIn
                  </a>
                </li>
                <li>
                  <a
                    href="https://web.facebook.com/profile.php?id=61579574771957"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted hover:text-accent transition-colors"
                  >
                    Facebook
                  </a>
                </li>
                <li>
                  <a
                    href="https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted hover:text-accent transition-colors"
                  >
                    Metrics Drive
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-border pt-6 text-xs text-muted-2 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} Enoch Adesina. All rights reserved.</p>
          <p>Klaviyo Certified · HubSpot Certified · Next.js</p>
        </div>
      </div>
    </footer>
  );
}
