export type Testimonial = {
  quote: string;
  author: string;
  role?: string;
  rating: number;
  project?: string;
};

export const testimonials: Testimonial[] = [
  {
    quote:
      "Enoch did an excellent job throughout the project. He was professional, responsive, and communicated clearly at every stage. He took the time to understand the project requirements, asked thoughtful questions, and delivered reliable results.",
    author: "Client",
    role: "Brevo Email Marketing & CRM Specialist project",
    rating: 5.0,
    project: "Voltix / Brevo infrastructure",
  },
  {
    quote:
      "Working with Enoch was a great experience. He demonstrated excellent talent, accuracy, and speed while handling the project professionally, communicating clearly, and delivering reliable results on time.",
    author: "Client",
    role: "Klaviyo Email Marketing Expert",
    rating: 5.0,
  },
  {
    quote:
      "Clear communicator, detail oriented, and accountable for outcomes. Delivered clean, on-brand email work and was easy to collaborate with.",
    author: "Client",
    role: "Klaviyo design project",
    rating: 5.0,
  },
];
