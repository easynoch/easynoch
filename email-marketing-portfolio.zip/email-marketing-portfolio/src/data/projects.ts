export type Project = {
  slug: string;
  title: string;
  client: string;
  clientUrl?: string;
  category: string;
  year: string;
  platform: string;
  excerpt: string;
  description: string;
  coverColor: string;
  metrics: { label: string; value: string }[];
  tags: string[];
  challenge: string;
  solution: string;
  results: string;
  figmaUrl?: string;
  metricsDriveUrl?: string;
  /** Filenames in /public/screenshots/ (optional) */
  screenshots?: string[];
};

export const projects: Project[] = [
  {
    slug: "revital-campaigns",
    title: "High-Open-Rate Campaigns for Revital Supplements",
    client: "Revital",
    category: "Health & Supplements",
    year: "2025",
    platform: "Klaviyo",
    excerpt:
      "Consistent ~50% open rates across large sends (22k+ recipients) with strong deliverability and measurable revenue per campaign.",
    description:
      "Campaign execution for a UK supplements brand. Subject lines, segmented sends to engaged cohorts, and clean deliverability (99.5%+ delivery rates).",
    coverColor: "#0d9488",
    metrics: [
      { label: "Avg Open Rate", value: "~50%" },
      { label: "Recipients / Send", value: "22k+" },
      { label: "Delivery Rate", value: "99.5%+" },
      { label: "Peak Campaign Rev", value: "£3,702" },
    ],
    tags: ["Klaviyo", "Campaigns", "Supplements", "UK", "High Open Rate"],
    challenge:
      "Needed consistent campaign performance on a large list while protecting deliverability and driving placed orders.",
    solution:
      "Segmented sends to engaged cohorts (30/60/90/180 day engaged), strong subject lines, and careful list hygiene. Campaigns included spring sales, brand features, and urgency-driven offers.",
    results:
      "Open rates consistently around 49–51% on 22,000+ recipient sends. Delivery rates 99.5–99.8%. Individual campaigns drove £1,300–£3,700 in attributed revenue with very low spam complaint rates (0–0.1%).",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: [
      "revital-campaign-1.png",
      "revital-campaign-2.png",
      "revital-campaign-3.png",
      "revital-campaign-4.png",
      "revital-campaign-5.png",
    ],
  },

  {
    slug: "house-of-stallion",
    title: "Full Klaviyo System for Tall Women's Fashion",
    client: "House of Stallion",
    clientUrl: "https://www.houseofstallion.com",
    category: "Fashion & Apparel",
    year: "2026",
    platform: "Klaviyo + Shopify",
    excerpt:
      "Built a complete Klaviyo email system from the ground up for an Australian tall women's fashion brand — flows, sign-up forms, and campaigns.",
    description:
      "End-to-end Klaviyo build: multi-step height & inseam focused sign-up form, Welcome, Browse Abandonment, Abandoned Cart, Post-Purchase, and VIP re-engagement. Designed all emails in Figma first.",
    coverColor: "#1c1917",
    metrics: [
      { label: "Flows Built", value: "6+" },
      { label: "Platform", value: "Klaviyo" },
      { label: "Client Action", value: "Restarted Contract" },
      { label: "Focus", value: "Retention" },
    ],
    tags: ["Klaviyo", "Shopify", "Flows", "Figma Design", "Australia"],
    challenge:
      "An Australian tall women's fashion brand needed a complete email marketing system with height and inseam-focused segmentation, clean on-brand designs, and reliable Shopify-to-Klaviyo sync.",
    solution:
      "Built a multi-step sign-up form capturing height and inseam data, then designed and implemented Welcome, Browse Abandonment, Abandoned Cart, Post-Purchase, and VIP re-engagement flows. All emails were designed in Figma before being built in Klaviyo. Managed full list import and subscriber sync from Shopify.",
    results:
      "Client was satisfied enough to restart the contract and continue the partnership. Solid foundation for ongoing retention revenue from email.",
    figmaUrl: "https://www.figma.com/design/DgEwjHd4A7cwawKGh0wfav/HOUSE-OF-STALLION",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: [
      "house-of-stallion-1.png",
      "house-of-stallion-2.png",
      "house-of-stallion-3.png",
    ],
  },
  {
    slug: "probate-realty-solutions",
    title: "11 Empathetic Email Workflows for Probate Real Estate",
    client: "Probate Realty Solutions",
    clientUrl: "https://www.probaterealtysolutions.com",
    category: "Real Estate",
    year: "2026",
    platform: "Go High Level",
    excerpt:
      "Designed and built 11 conversion-focused email workflow templates for a US real estate company specializing in probate and estate sales.",
    description:
      "Full email workflow design system inside Go High Level — empathetic messaging, diverse imagery, proper branding, and organized campaign structure.",
    coverColor: "#134e4a",
    metrics: [
      { label: "Templates", value: "11" },
      { label: "Platform", value: "Go High Level" },
      { label: "Milestone", value: "Increased" },
      { label: "Outcome", value: "Ongoing Interest" },
    ],
    tags: ["Go High Level", "Real Estate", "Workflow Design", "USA"],
    challenge:
      "A real estate company focused on probate needed email templates that felt empathetic and trustworthy while still driving conversions in a sensitive vertical.",
    solution:
      "Designed and built 11 email workflow templates inside Go High Level with careful tone, diverse imagery, strong branding, and clear structure.",
    results:
      "Client approved the work, increased the milestone value, and expressed interest in ongoing collaboration.",
    figmaUrl:
      "https://www.figma.com/design/2w6F1KmIj5mmLXflxaAbMo/PROBATE-REALTY-SOLUTION",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: ["probate-1.png", "probate-2.png"],
  },
  {
    slug: "salon-station-clinic",
    title: "Mailchimp System + Signature Lift Campaign",
    client: "Salon Station The Clinic",
    clientUrl: "https://www.salonstation.com.au",
    category: "Beauty Clinic",
    year: "2026",
    platform: "Mailchimp + Shopify",
    excerpt:
      "Full email system for a luxury Australian skin clinic plus a promotional campaign for their Signature Lift treatment launched to 11,000+ contacts.",
    description:
      "Welcome Flow, Abandoned Booking automation, and a high-impact promotional campaign (Signature Lift: was $1,200 → $500) with a dedicated Shopify landing page.",
    coverColor: "#9d174d",
    metrics: [
      { label: "Contacts", value: "11,000+" },
      { label: "Offer", value: "$1,200 → $500" },
      { label: "Platform", value: "Mailchimp" },
      { label: "Focus", value: "First Send" },
    ],
    tags: ["Mailchimp", "Shopify", "Beauty", "Australia", "Automation"],
    challenge:
      "A luxury skin clinic needed a complete email marketing foundation and a strong promotional push for their Signature Lift treatment.",
    solution:
      "Set up Welcome Flow and Abandoned Booking automation in Mailchimp. Built a Shopify landing page and promotional campaign for the Signature Lift treatment and launched to 11,000+ contacts.",
    results:
      "Strong engagement on the very first send. The clinic gained a working email system and a proven promotional template.",
    figmaUrl: "https://www.figma.com/design/pHHKl9RoEwPSmYW908oa4d/SALOON-CLINICS",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: ["salon-1.png", "salon-2.png", "salon-3.png"],
  },
  {
    slug: "voltix-supply",
    title: "CRM & Email Infrastructure for Energy Ecommerce",
    client: "Voltix Supply",
    clientUrl: "https://www.voltixsupply.com",
    category: "Energy / Ecommerce",
    year: "2026",
    platform: "Brevo + WooCommerce",
    excerpt:
      "Milestone-based CRM and email infrastructure build for a portable power and solar energy brand — authentication, integration, and tracking.",
    description:
      "Completed SPF/DKIM/DMARC authentication, sending domain setup, WooCommerce ↔ Brevo integration, contact sync, custom field mapping, and ecommerce tracking.",
    coverColor: "#a16207",
    metrics: [
      { label: "Milestones", value: "2 Approved" },
      { label: "Platform", value: "Brevo" },
      { label: "Auth", value: "SPF/DKIM/DMARC" },
      { label: "Status", value: "In Progress" },
    ],
    tags: ["Brevo", "WooCommerce", "Deliverability", "CRM", "Energy"],
    challenge:
      "A new ecommerce brand in portable power and solar needed solid email infrastructure from day one.",
    solution:
      "Milestone 1: SPF, DKIM, DMARC, sending domain, deliverability. Milestone 2: WooCommerce to Brevo integration, contact sync, custom fields, ecommerce tracking.",
    results:
      "Both milestones approved and paid. Foundation ready for ongoing CRM and email growth.",
    figmaUrl:
      "https://www.figma.com/design/U2vv2VbOxaQpDYHVgVtx7h/Voltix-Supply?node-id=0-1",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: ["voltix-1.png"],
  },
  {
    slug: "butter-beauty",
    title: "Welcome Email for Danish Skincare Rebrand",
    client: "Butter Beauty (via Converzion Agency)",
    category: "Beauty & Skincare",
    year: "2026",
    platform: "Klaviyo",
    excerpt:
      "Delivered the first welcome email for a rebranding Danish skincare client, fully aligned with agency brand templates and tone of voice.",
    description:
      "Flow execution specialist for a Danish ecommerce agency. Built the opening welcome email for Butter Beauty to match strict brand and copy guidelines.",
    coverColor: "#881337",
    metrics: [
      { label: "Role", value: "Flow Specialist" },
      { label: "Platform", value: "Klaviyo" },
      { label: "Focus", value: "Brand Alignment" },
      { label: "Agency", value: "Converzion" },
    ],
    tags: ["Klaviyo", "Agency", "Skincare", "Denmark", "Welcome Flow"],
    challenge:
      "Agency needed a reliable flow execution specialist who could match existing brand templates, tone of voice, and copywriting frameworks exactly.",
    solution:
      "Delivered the first welcome email for Butter Beauty’s rebrand, carefully following the agency’s design system, voice guidelines, and structure.",
    results:
      "Email approved and delivered as the starting point of the client’s new welcome experience.",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: ["butter-1.png"],
  },
  {
    slug: "roseaura-boutique",
    title: "Email Revenue from 12% → 25–30% of Store Sales",
    client: "RoseAura Boutique",
    category: "Beauty / DTC",
    year: "2023–Present",
    platform: "Klaviyo + Shopify",
    excerpt:
      "Ongoing Klaviyo revenue partnership. Started with a full audit that more than doubled email’s contribution to monthly revenue.",
    description:
      "Long-term retention partner. Full audit, segmented campaign calendars, lifecycle flow optimization, and monthly performance reporting.",
    coverColor: "#5b21b6",
    metrics: [
      { label: "Email Share", value: "12% → 25–30%" },
      { label: "Role", value: "Revenue Partner" },
      { label: "Platform", value: "Klaviyo" },
      { label: "Duration", value: "Ongoing" },
    ],
    tags: ["Klaviyo", "Shopify", "Retention", "Revenue Growth"],
    challenge:
      "Email was underperforming and contributing only ~12% of total monthly revenue.",
    solution:
      "Full Klaviyo audit, prioritized highest-impact fixes, stronger segmentation, optimized core flows, and a consistent campaign calendar with monthly reporting.",
    results:
      "Email contribution grew from 12% to a consistent 25–30% of store revenue. Partnership continues.",
    metricsDriveUrl:
      "https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link",
    screenshots: ["roseaura-1.png", "roseaura-2.png"],
  },
];

export function getProject(slug: string): Project | undefined {
  return projects.find((p) => p.slug === slug);
}

export const designSamples = [
  {
    name: "RENEW",
    category: "Beauty & Skincare",
    figmaUrl:
      "https://www.figma.com/design/lQI7nGoSNZAkhfcHVRrIp4/RENEW?node-id=0-1",
    color: "#e11d48",
    screenshot: "renew.png",
  },
  {
    name: "Valeva",
    category: "Beauty & Skincare",
    figmaUrl:
      "https://www.figma.com/design/RXrRdl0upeDwmG4L0EhjNQ/Valeva?node-id=0-1",
    color: "#db2777",
    screenshot: "valeva.png",
  },
  {
    name: "LA LUNA SKIN",
    category: "Beauty & Skincare",
    figmaUrl:
      "https://www.figma.com/design/ayvZBPnDvu1ZlCgVJorUUN/LA-LUNA-SKIN?node-id=0-1",
    color: "#a21caf",
    screenshot: "la-luna.png",
  },
  {
    name: "NUARAI",
    category: "Home & Lifestyle",
    figmaUrl:
      "https://www.figma.com/design/qU3fXJW4vevPNOKD9rldRS/NUARAI?node-id=0-1",
    color: "#0d9488",
    screenshot: "nuarai.png",
  },
  {
    name: "Inrama",
    category: "Fashion & Apparel",
    figmaUrl:
      "https://www.figma.com/design/inwD47sPAiSUzP8GxbrZwc/inrama?node-id=0-1",
    color: "#1e293b",
    screenshot: "inrama.png",
  },
  {
    name: "MOOMENN",
    category: "Fashion & Apparel",
    figmaUrl:
      "https://www.figma.com/design/4tqczhiTyJS8vDGq8SHgHi/MOOMENN?node-id=0-1",
    color: "#4338ca",
    screenshot: "moomenn.png",
  },
  {
    name: "ALWRLD",
    category: "Fashion & Apparel",
    figmaUrl:
      "https://www.figma.com/design/TCuRJizVhMxxIDfqs6zv08/ALWRLD?node-id=0-1",
    color: "#0f172a",
    screenshot: "alwrld.png",
  },
  {
    name: "DeepZeez",
    category: "Fashion & Apparel",
    figmaUrl:
      "https://www.figma.com/design/dpGVsRvVqkmJAhOQL1VvlP/DeepZeez?node-id=0-1",
    color: "#1e3a5f",
    screenshot: "deepzeez.png",
  },
  {
    name: "Above Normal",
    category: "Fashion & Apparel",
    figmaUrl:
      "https://www.figma.com/design/tXk9sUyCwptkZQSjn58SRZ/above-normal?node-id=0-1",
    color: "#334155",
    screenshot: "above-normal.png",
  },
  {
    name: "THE PREMIER JERSEYS",
    category: "Sports & Fan Merch",
    figmaUrl:
      "https://www.figma.com/design/g4KLaAit9CWAHkcEm3EGXv/THE-PREMIER-JERSEYS?node-id=0-1",
    color: "#b91c1c",
    screenshot: "premier-jerseys.png",
  },
  {
    name: "SA Note",
    category: "Food & Beverage",
    figmaUrl: "https://www.figma.com/design/XRNJrrid1ScJnIVxeZ4H8A/SA-Note",
    color: "#b45309",
    screenshot: "sa-note.png",
  },
  {
    name: "HOUSE OF STALLION",
    category: "Fashion & Apparel",
    figmaUrl: "https://www.figma.com/design/DgEwjHd4A7cwawKGh0wfav/HOUSE-OF-STALLION",
    color: "#1c1917",
    screenshot: "hos-design.png",
  },
];
