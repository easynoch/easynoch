import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import { testimonials } from "@/data/testimonials";

export const metadata = {
  title: "About | Enoch Adesina",
  description:
    "Klaviyo Email Marketing Specialist for Shopify DTC brands. Top Rated on Upwork.",
};

export default function AboutPage() {
  return (
    <div>
      {/* Hero with photo */}
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <div className="grid gap-12 md:grid-cols-[240px_1fr] md:items-start">
            <div className="relative mx-auto h-56 w-56 overflow-hidden rounded-2xl border border-border md:mx-0 md:h-64 md:w-64">
              <Image
                src="/enoch.jpg"
                alt="Enoch Adesina"
                fill
                className="object-cover object-top"
                priority
                sizes="256px"
              />
            </div>
            <div>
              <p className="text-sm font-medium uppercase tracking-widest text-accent">
                About
              </p>
              <h1 className="mt-3 text-4xl font-bold tracking-tight md:text-5xl text-balance">
                I help Shopify brands turn email into a reliable revenue channel.
              </h1>
              <p className="mt-5 max-w-xl text-lg text-muted leading-relaxed">
                I’m Enoch Adesina — a Klaviyo Email Marketing Specialist focused on
                flows, campaigns, segmentation, and deliverability for DTC and
                Shopify brands. Top Rated on Upwork with 100% Job Success.
              </p>
              <p className="mt-4 text-sm font-medium text-accent">
                $12/hr · Based in Nigeria · Open for work worldwide
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-6 py-16">
        <p className="text-lg leading-relaxed text-muted">
          Most brands treat email as a broadcast tool. I treat it as a system:
          clear journeys, solid deliverability, clean design, and measurable
          outcomes. Whether you need a full Klaviyo rebuild, better flows, or
          ongoing campaign support, I focus on practical work that improves
          retention and revenue.
        </p>
        <p className="mt-6 text-lg leading-relaxed text-muted">
          I’m Klaviyo certified (Product + Email Deliverability) and HubSpot
          certified (Inbound, Digital, Social Media, Ecommerce Marketing). I
          also work across Mailchimp, Brevo, Omnisend, ActiveCampaign, and Go
          High Level when needed.
        </p>
      </section>

      {/* Testimonials */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">
            Client feedback
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight">
            What clients say on Upwork
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <blockquote
                key={i}
                className="rounded-2xl border border-border bg-background p-6"
              >
                <div className="flex gap-0.5 text-accent text-sm">
                  {"★".repeat(Math.round(t.rating))}
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted">
                  “{t.quote}”
                </p>
                <footer className="mt-4 text-sm">
                  <span className="font-medium">{t.author}</span>
                  {t.role && (
                    <span className="block text-xs text-muted-2 mt-0.5">
                      {t.role}
                    </span>
                  )}
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <h2 className="text-3xl font-bold tracking-tight">What I offer</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {[
            {
              title: "Klaviyo Audit & Strategy",
              items: [
                "Full account audit and gap prioritization",
                "Segmentation and journey mapping",
                "Clear plan for highest-impact fixes",
                "KPI and reporting setup",
              ],
            },
            {
              title: "Flows & Automations",
              items: [
                "Welcome, abandoned cart, browse abandonment",
                "Post-purchase, win-back, replenishment, VIP",
                "Clean build and testing in Klaviyo",
                "Copy and design aligned to brand",
              ],
            },
            {
              title: "Campaigns & Design",
              items: [
                "Email design in Figma",
                "Campaign calendars and segmentation",
                "Subject lines and conversion-focused copy",
                "A/B testing and performance review",
              ],
            },
            {
              title: "Deliverability & Migrations",
              items: [
                "SPF, DKIM, DMARC setup",
                "Domain authentication and list hygiene",
                "Shopify / WooCommerce integrations",
                "Migrations between platforms",
              ],
            },
          ].map((service) => (
            <div
              key={service.title}
              className="rounded-2xl border border-border bg-card p-6"
            >
              <h3 className="text-lg font-semibold">{service.title}</h3>
              <ul className="mt-4 space-y-2">
                {service.items.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2 text-sm text-muted"
                  >
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Certs */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <h2 className="text-2xl font-bold tracking-tight">Certifications</h2>
          <div className="mt-6 flex flex-wrap gap-3">
            {[
              "Klaviyo Product Certification",
              "Klaviyo Email Deliverability",
              "HubSpot Inbound Marketing",
              "HubSpot Email Marketing",
              "HubSpot Digital Marketing",
              "HubSpot Social Media",
              "HubSpot Ecommerce Marketing",
            ].map((cert) => (
              <span
                key={cert}
                className="rounded-full border border-border bg-card px-4 py-2 text-sm"
              >
                {cert}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-16 text-center">
          <h2 className="text-3xl font-bold tracking-tight">
            Ready to improve your email program?
          </h2>
          <p className="mx-auto mt-3 max-w-md text-muted">
            Share your current setup and goals. I’ll tell you honestly how I can help.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-8 py-3.5 text-sm font-semibold text-white transition hover:bg-accent-hover"
            >
              Get in touch <ArrowUpRight size={16} />
            </Link>
            <a
              href="https://wa.me/2348131475529"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border px-8 py-3.5 text-sm font-semibold transition hover:border-green-500 hover:text-green-400"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
