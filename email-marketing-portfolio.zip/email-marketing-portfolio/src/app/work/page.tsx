"use client";

import Link from "next/link";
import { projects } from "@/data/projects";
import { ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.45 },
  }),
};

export default function WorkPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <div className="max-w-2xl">
        <p className="text-sm font-medium uppercase tracking-widest text-accent">
          Portfolio
        </p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
          Selected work
        </h1>
        <p className="mt-4 text-lg text-muted">
          Real client projects across Klaviyo, Mailchimp, Brevo, and Go High Level —
          fashion, beauty, real estate, energy, and more.
        </p>
      </div>

      <div className="mt-16 grid gap-8 md:grid-cols-2">
        {projects.map((project, i) => (
          <motion.div
            key={project.slug}
            custom={i}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            variants={fadeUp}
          >
            <Link
              href={`/work/${project.slug}`}
              className="group block overflow-hidden rounded-2xl border border-border bg-card transition hover:border-accent/40"
            >
              <div
                className="aspect-[16/9] w-full relative"
                style={{ backgroundColor: project.coverColor }}
              >
                <div className="absolute inset-0 flex items-end justify-between p-6">
                  <span className="rounded-full bg-black/30 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
                    {project.category}
                  </span>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-black/30 text-white opacity-0 transition group-hover:opacity-100 backdrop-blur-sm">
                    <ArrowUpRight size={18} />
                  </span>
                </div>
              </div>
              <div className="p-6">
                <p className="text-xs text-muted">
                  {project.client} · {project.platform} · {project.year}
                </p>
                <h2 className="mt-2 text-xl font-semibold group-hover:text-accent transition-colors">
                  {project.title}
                </h2>
                <p className="mt-2 text-sm text-muted line-clamp-2">
                  {project.excerpt}
                </p>

                <div className="mt-5 flex flex-wrap gap-3">
                  {project.metrics.map((m) => (
                    <div
                      key={m.label}
                      className="rounded-lg bg-background px-3 py-2"
                    >
                      <p className="text-sm font-bold">{m.value}</p>
                      <p className="text-[11px] text-muted">{m.label}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-border px-2.5 py-0.5 text-xs text-muted"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
