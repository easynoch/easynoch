import Link from "next/link";
import { notFound } from "next/navigation";
import { getProject, projects } from "@/data/projects";
import { ArrowLeft, ArrowUpRight, ExternalLink } from "lucide-react";
import { ScreenshotPlaceholder } from "@/components/ScreenshotPlaceholder";
import Image from "next/image";
import { existsSync } from "fs";
import path from "path";

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) return {};
  return {
    title: `${project.title} | Enoch Adesina`,
    description: project.excerpt,
  };
}

function Screenshot({ filename, label }: { filename: string; label: string }) {
  const publicPath = path.join(process.cwd(), "public", "screenshots", filename);
  const hasImage = existsSync(publicPath);

  if (hasImage) {
    return (
      <div className="overflow-hidden rounded-xl border border-border">
        <Image
          src={`/screenshots/${filename}`}
          alt={label}
          width={600}
          height={750}
          className="w-full object-cover"
        />
      </div>
    );
  }

  return <ScreenshotPlaceholder label={label} aspect="email" />;
}

export default async function CaseStudyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) notFound();

  const shots = project.screenshots ?? [];

  return (
    <article>
      {/* Hero */}
      <section
        className="relative border-b border-border"
        style={{ backgroundColor: project.coverColor }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-black/40" />
        <div className="relative mx-auto max-w-6xl px-6 py-16 md:py-24">
          <Link
            href="/work"
            className="inline-flex items-center gap-2 text-sm font-medium text-white/80 hover:text-white transition"
          >
            <ArrowLeft size={16} /> Back to work
          </Link>
          <div className="mt-8">
            <p className="text-sm font-medium tracking-wide text-white/75">
              {project.client} · {project.platform} · {project.year}
            </p>
            <h1 className="mt-3 max-w-3xl text-4xl font-bold tracking-tight text-white md:text-5xl lg:text-[3.25rem] leading-[1.15]">
              {project.title}
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-white/85">
              {project.excerpt}
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              {project.clientUrl && (
                <a
                  href={project.clientUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm hover:bg-white/25 transition"
                >
                  Visit client site <ExternalLink size={14} />
                </a>
              )}
              {project.figmaUrl && (
                <a
                  href={project.figmaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm hover:bg-white/25 transition"
                >
                  View Figma designs <ExternalLink size={14} />
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Metrics */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-6 py-12 md:grid-cols-4">
          {project.metrics.map((m) => (
            <div key={m.label}>
              <p className="text-3xl font-bold tracking-tight md:text-4xl">
                {m.value}
              </p>
              <p className="mt-1.5 text-sm text-muted">{m.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Screenshots */}
      {shots.length > 0 && (
        <section className="border-b border-border">
          <div className="mx-auto max-w-6xl px-6 py-16">
            <h2 className="text-sm font-semibold uppercase tracking-widest text-accent">
              Email designs
            </h2>
            <p className="mt-2 text-muted">
              Preview of emails from this project. Replace placeholders with real exports from Figma.
            </p>
            <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {shots.map((file, i) => (
                <Screenshot
                  key={file}
                  filename={file}
                  label={`Email ${i + 1} — ${project.client}`}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Story */}
      <section className="mx-auto max-w-3xl px-6 py-16 md:py-24">
        <div className="space-y-14">
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-widest text-accent">
              The Challenge
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted">
              {project.challenge}
            </p>
          </div>
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-widest text-accent">
              The Solution
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted">
              {project.solution}
            </p>
          </div>
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-widest text-accent">
              The Results
            </h2>
            <p className="mt-4 text-lg leading-relaxed text-muted">
              {project.results}
            </p>
          </div>
        </div>

        <div className="mt-14 flex flex-wrap gap-3">
          {project.figmaUrl && (
            <a
              href={project.figmaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-medium transition hover:border-accent hover:text-accent"
            >
              Open Figma file <ExternalLink size={14} />
            </a>
          )}
          {project.metricsDriveUrl && (
            <a
              href={project.metricsDriveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-medium transition hover:border-accent hover:text-accent"
            >
              View metrics & results <ExternalLink size={14} />
            </a>
          )}
        </div>

        <div className="mt-10 flex flex-wrap gap-2 border-t border-border pt-8">
          {project.tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full border border-border px-3 py-1 text-sm text-muted"
            >
              {tag}
            </span>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-6 py-14 md:flex-row md:items-center">
          <div>
            <p className="text-sm text-muted">Want results like this?</p>
            <p className="mt-1 text-xl font-semibold tracking-tight">
              Let’s improve your Klaviyo or email system.
            </p>
          </div>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white transition hover:bg-accent-hover"
          >
            Start a project <ArrowUpRight size={16} />
          </Link>
        </div>
      </section>
    </article>
  );
}
