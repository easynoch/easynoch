import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Enoch Adesina | Klaviyo Email Marketing Specialist",
  description:
    "Klaviyo Email Marketing Specialist for Shopify DTC brands. Flows, campaigns, deliverability, and revenue growth. Top Rated on Upwork.",
  keywords: [
    "Klaviyo",
    "email marketing",
    "Shopify",
    "email flows",
    "DTC",
    "email design",
    "deliverability",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen flex flex-col`}
      >
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
