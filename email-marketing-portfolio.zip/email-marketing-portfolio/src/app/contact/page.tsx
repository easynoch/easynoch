"use client";

import { useState } from "react";
import { ArrowUpRight, CheckCircle2, MessageCircle, AlertCircle } from "lucide-react";

/**
 * FORM BACKEND SETUP (Formspree — free, no backend needed)
 * 1. Go to https://formspree.io and create a free account
 * 2. Create a new form → copy the form ID (looks like: xyzabcde)
 * 3. Replace FORMSPREE_ID below with your ID
 * 4. Redeploy. Messages will go to the email you registered with.
 */
const FORMSPREE_ID = "YOUR_FORMSPREE_ID"; // ← replace this

export default function ContactPage() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">(
    "idle"
  );

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("loading");

    const form = e.currentTarget;
    const data = new FormData(form);

    // If Formspree ID not set yet, fall back to simulated success
    // so the UI still works while you set it up
    if (FORMSPREE_ID === "YOUR_FORMSPREE_ID") {
      await new Promise((r) => setTimeout(r, 900));
      setStatus("success");
      form.reset();
      return;
    }

    try {
      const res = await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" },
      });

      if (res.ok) {
        setStatus("success");
        form.reset();
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <div className="grid gap-16 lg:grid-cols-2">
        {/* Left column */}
        <div>
          <p className="text-sm font-medium uppercase tracking-widest text-accent">
            Contact
          </p>
          <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl text-balance">
            Let’s improve your email program
          </h1>
          <p className="mt-4 text-lg text-muted leading-relaxed">
            Tell me about your current setup and goals. I usually reply within a few hours.
          </p>

          <div className="mt-10 space-y-6 text-sm">
            <div>
              <p className="text-muted-2 text-xs uppercase tracking-wider mb-1">Rate</p>
              <p className="font-semibold text-accent text-base">$12 / hour · Top Rated on Upwork</p>
            </div>
            <div>
              <p className="text-muted-2 text-xs uppercase tracking-wider mb-1">WhatsApp</p>
              <a
                href="https://wa.me/2348131475529"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 font-medium hover:text-accent transition-colors"
              >
                <MessageCircle size={16} className="text-green-500" />
                +234 813 147 5529
              </a>
            </div>
            <div>
              <p className="text-muted-2 text-xs uppercase tracking-wider mb-1">LinkedIn</p>
              <a
                href="https://www.linkedin.com/in/adebare-enoch-950a29404/"
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium hover:text-accent transition-colors"
              >
                linkedin.com/in/adebare-enoch
              </a>
            </div>
            <div>
              <p className="text-muted-2 text-xs uppercase tracking-wider mb-1">Facebook</p>
              <a
                href="https://web.facebook.com/profile.php?id=61579574771957"
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium hover:text-accent transition-colors"
              >
                Profile
              </a>
            </div>
            <div>
              <p className="text-muted-2 text-xs uppercase tracking-wider mb-1">Best fit</p>
              <p className="font-medium leading-relaxed">
                Shopify / DTC brands · Klaviyo audits & flows · Campaign support · Deliverability
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="rounded-2xl border border-border bg-card p-6 md:p-8">
          {status === "success" ? (
            <div className="flex flex-col items-center justify-center py-14 text-center">
              <CheckCircle2 className="h-12 w-12 text-accent" />
              <h3 className="mt-4 text-xl font-semibold">Message sent</h3>
              <p className="mt-2 text-muted max-w-xs">
                Thanks for reaching out. I’ll get back to you soon — or message me on WhatsApp for a faster reply.
              </p>
              <a
                href="https://wa.me/2348131475529"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-green-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition"
              >
                <MessageCircle size={16} /> Open WhatsApp
              </a>
              <button
                onClick={() => setStatus("idle")}
                className="mt-4 text-sm text-muted hover:text-foreground transition"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1.5">
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    required
                    className="w-full rounded-xl border border-border bg-background px-3.5 py-2.5 text-sm outline-none transition focus:border-accent placeholder:text-muted-2"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1.5">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    className="w-full rounded-xl border border-border bg-background px-3.5 py-2.5 text-sm outline-none transition focus:border-accent placeholder:text-muted-2"
                    placeholder="you@company.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="platform" className="block text-sm font-medium mb-1.5">
                  Current platform
                </label>
                <select
                  id="platform"
                  name="platform"
                  className="w-full rounded-xl border border-border bg-background px-3.5 py-2.5 text-sm outline-none transition focus:border-accent"
                >
                  <option value="">Select platform</option>
                  <option value="klaviyo">Klaviyo</option>
                  <option value="mailchimp">Mailchimp</option>
                  <option value="brevo">Brevo</option>
                  <option value="omnisend">Omnisend</option>
                  <option value="ghl">Go High Level</option>
                  <option value="other">Other / Not sure</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-1.5">
                  What do you need help with?
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={5}
                  className="w-full resize-none rounded-xl border border-border bg-background px-3.5 py-2.5 text-sm outline-none transition focus:border-accent placeholder:text-muted-2"
                  placeholder="e.g. Need a Klaviyo audit, better abandoned cart flow, campaign support, deliverability help..."
                />
              </div>

              {status === "error" && (
                <div className="flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2.5 text-sm text-red-400">
                  <AlertCircle size={16} />
                  Something went wrong. Please try WhatsApp or try again.
                </div>
              )}

              <button
                type="submit"
                disabled={status === "loading"}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-60"
              >
                {status === "loading" ? "Sending..." : "Send message"}
                {status !== "loading" && <ArrowUpRight size={16} />}
              </button>

              <p className="text-center text-xs text-muted">
                Prefer chat?{" "}
                <a
                  href="https://wa.me/2348131475529"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  Message me on WhatsApp
                </a>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
