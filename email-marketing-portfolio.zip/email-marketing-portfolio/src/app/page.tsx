"use client";

import Link from "next/link";
import Image from "next/image";
import { projects } from "@/data/projects";
import { testimonials } from "@/data/testimonials";
import { ArrowUpRight, Mail, Zap, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: "easeOut" },
  }),
};

export default function HomePage() {
  const featured = projects.slice(0, 3);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-accent/15 via-transparent to-transparent" />
        <div className="relative mx-auto max-w-6xl px-6 py-20 md:py-28">
          <div className="grid gap-12 lg:grid-cols-[1fr_220px] lg:items-center">
            <div>
              <motion.p
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="mb-4 text-sm font-medium uppercase tracking-widest text-accent"
              >
                Klaviyo Email Marketing Specialist · Shopify DTC
              </motion.p>
              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="max-w-2xl text-4xl font-bold leading-[1.15] tracking-tight md:text-5xl lg:text-6xl text-balance"
              >
                Email systems that{" "}
                <span className="text-accent">grow revenue</span>
                <br className="hidden sm:block" /> — not just look good.
              </motion.h1>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-5 max-w-xl text-lg text-muted leading-relaxed"
              >
                I help Shopify and DTC brands build better Klaviyo flows, campaigns,
                segmentation, and deliverability. Top Rated on Upwork. $12/hr.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-8 flex flex-wrap gap-3"
              >
                <Link
                  href="/work"
                  className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white transition hover:bg-accent-hover"
                >
                  View selected work
                  <ArrowUpRight size={16} />
                </Link>
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold transition hover:border-accent hover:text-accent"
                >
                  Start a project
                </Link>
                <a
                  href="https://wa.me/2348131475529"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold transition hover:border-green-500 hover:text-green-400"
                >
                  WhatsApp
                </a>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.25 }}
              className="relative mx-auto hidden h-52 w-52 overflow-hidden rounded-2xl border border-border shadow-2xl shadow-black/40 lg:block lg:h-56 lg:w-56"
            >
              <Image
                src="/enoch.jpg"
                alt="Enoch Adesina"
                fill
                className="object-cover object-top"
                priority
                sizes="224px"
              />
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-14 grid grid-cols-2 gap-6 border-t border-border pt-10 md:grid-cols-4"
          >
            {[
              { label: "Job Success", value: "100%" },
              { label: "Jobs Completed", value: "17+" },
              { label: "Rate", value: "$12/hr" },
              { label: "Certifications", value: "Klaviyo + HubSpot" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-2xl font-bold tracking-tight md:text-3xl">
                  {stat.value}
                </p>
                <p className="mt-1 text-sm text-muted">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Proof strip - real metrics */}
      <section className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-accent">
                Recent campaign results
              </p>
              <p className="mt-1 text-sm text-muted">
                Revital supplements · Klaviyo · ~22k recipients per send
              </p>
              <Link href="/results" className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-accent hover:underline">
                View full results <ArrowUpRight size={12} />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-6 sm:grid-cols-4 sm:gap-8">
              {[
                { value: "~50%", label: "Open rate" },
                { value: "99.5%+", label: "Delivery" },
                { value: "£3.7k", label: "Peak campaign rev" },
                { value: "0–0.1%", label: "Spam rate" },
              ].map((m) => (
                <div key={m.label}>
                  <p className="text-xl font-bold tracking-tight">{m.value}</p>
                  <p className="text-xs text-muted">{m.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Work */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-widest text-accent">
              Selected Work
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight md:text-4xl">
              Real projects. Real results.
            </h2>
          </div>
          <Link
            href="/work"
            className="hidden items-center gap-1 text-sm font-medium text-muted transition hover:text-accent md:flex"
          >
            View all <ArrowUpRight size={14} />
          </Link>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {featured.map((project, i) => (
            <motion.div
              key={project.slug}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={fadeUp}
            >
              <Link
                href={`/work/${project.slug}`}
                className="group relative block overflow-hidden rounded-2xl border border-border bg-card transition hover:border-accent/50"
              >
                <div
                  className="aspect-[4/3] w-full"
                  style={{ backgroundColor: project.coverColor }}
                >
                  <div className="flex h-full items-end p-6">
                    <span className="rounded-full bg-black/30 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
                      {project.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-xs text-muted">
                    {project.client} · {project.platform}
                  </p>
                  <h3 className="mt-1 text-lg font-semibold group-hover:text-accent transition-colors">
                    {project.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted">
                    {project.excerpt}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {project.metrics.slice(0, 2).map((m) => (
                      <span
                        key={m.label}
                        className="rounded-md bg-background px-2 py-1 text-xs font-medium"
                      >
                        {m.value}{" "}
                        <span className="text-muted">{m.label}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="border-y border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">
            Upwork feedback
          </p>
          <h2 className="mt-2 text-3xl font-bold tracking-tight">
            Clients trust the work
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <motion.blockquote
                key={i}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="rounded-2xl border border-border bg-background p-6"
              >
                <div className="text-accent text-sm">
                  {"★".repeat(Math.round(t.rating))}
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted">
                  “{t.quote}”
                </p>
                <footer className="mt-4 text-sm font-medium">{t.author}</footer>
              </motion.blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* How I help */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <p className="text-sm font-medium uppercase tracking-widest text-accent">
          How I help
        </p>
        <h2 className="mt-2 max-w-xl text-3xl font-bold tracking-tight md:text-4xl">
          Practical Klaviyo work that moves the numbers
        </h2>

        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {[
            {
              icon: <Zap className="h-6 w-6 text-accent" />,
              title: "Flows & Automations",
              desc: "Welcome, abandoned cart, browse abandonment, post-purchase, win-back, replenishment, and VIP flows built cleanly in Klaviyo.",
            },
            {
              icon: <Mail className="h-6 w-6 text-accent" />,
              title: "Campaigns & Design",
              desc: "On-brand email design in Figma, strong subject lines, and campaign calendars that drive repeat purchases.",
            },
            {
              icon: <ShieldCheck className="h-6 w-6 text-accent" />,
              title: "Deliverability & Setup",
              desc: "SPF, DKIM, DMARC, domain authentication, list hygiene, and platform migrations (Klaviyo, Brevo, Mailchimp, GHL).",
            },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-2xl border border-border bg-card p-6"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10">
                {item.icon}
              </div>
              <h3 className="text-lg font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-muted leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Metrics Drive CTA */}
      <section className="mx-auto max-w-6xl px-6 pb-8">
        <div className="rounded-2xl border border-border bg-card p-8 md:p-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-sm font-medium uppercase tracking-widest text-accent">
                Proof
              </p>
              <h2 className="mt-2 text-2xl font-bold tracking-tight">
                Campaign metrics & results
              </h2>
              <p className="mt-2 max-w-md text-muted text-sm leading-relaxed">
                Full Klaviyo reports, flow performance, and before/after dashboards — including the Revital campaigns and earlier 2.75% attributed revenue baseline.
              </p>
            </div>
            <a
              href="https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex shrink-0 items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white transition hover:bg-accent-hover"
            >
              Open Metrics Drive
              <ArrowUpRight size={16} />
            </a>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="text-3xl font-bold tracking-tight md:text-5xl text-balance">
          Need better Klaviyo flows
          <br />
          <span className="text-accent">or campaign support?</span>
        </h2>
        <p className="mx-auto mt-4 max-w-md text-muted">
          Tell me what you’re using now and what you want to improve. I reply fast.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 rounded-full bg-accent px-8 py-3.5 text-sm font-semibold text-white transition hover:bg-accent-hover"
          >
            Get in touch
            <ArrowUpRight size={16} />
          </Link>
          <a
            href="https://wa.me/2348131475529"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-border px-8 py-3.5 text-sm font-semibold transition hover:border-green-500 hover:text-green-400"
          >
            Chat on WhatsApp
          </a>
        </div>
      </section>
    </div>
  );
}
