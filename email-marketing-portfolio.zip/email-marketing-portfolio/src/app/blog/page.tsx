import Link from "next/link";

export const metadata = {
  title: "Blog | Alex Rivera",
  description: "Practical insights on email marketing strategy, design, and conversion.",
};

const posts = [
  {
    slug: "subject-line-framework",
    title: "The 4-Part Subject Line Framework That Consistently Hits 50%+ Opens",
    excerpt:
      "Most subject lines fail because they’re either too clever or too vague. Here’s a simple structure I use on almost every campaign.",
    date: "Oct 12, 2025",
    category: "Copywriting",
  },
  {
    slug: "welcome-sequence-mistakes",
    title: "5 Welcome Sequence Mistakes That Quietly Kill Lifetime Value",
    excerpt:
      "Your welcome flow is the highest-leverage email real estate you have. Most brands waste it.",
    date: "Sep 28, 2025",
    category: "Strategy",
  },
  {
    slug: "segmentation-that-actually-works",
    title: "Segmentation That Actually Works (Without Overcomplicating Everything)",
    excerpt:
      "You don’t need 47 segments. You need the right 5–7. Here’s how I think about it.",
    date: "Sep 3, 2025",
    category: "Strategy",
  },
  {
    slug: "design-system-for-email",
    title: "Building an Email Design System That Scales",
    excerpt:
      "How to create modular templates that stay on-brand while giving you speed and consistency across campaigns.",
    date: "Aug 15, 2025",
    category: "Design",
  },
];

export default function BlogPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <div className="max-w-2xl">
        <p className="text-sm font-medium uppercase tracking-widest text-accent">
          Blog
        </p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl">
          Notes on email that converts
        </h1>
        <p className="mt-4 text-lg text-muted">
          Practical frameworks, experiments, and lessons from real campaigns. No fluff.
        </p>
      </div>

      <div className="mt-16 space-y-8">
        {posts.map((post) => (
          <article
            key={post.slug}
            className="group border-b border-border pb-8 last:border-0"
          >
            <div className="flex items-center gap-3 text-xs text-muted">
              <span className="rounded-full border border-border px-2.5 py-0.5">
                {post.category}
              </span>
              <span>{post.date}</span>
            </div>
            <h2 className="mt-3 text-xl font-semibold group-hover:text-accent transition-colors md:text-2xl">
              {/* Placeholder links for now — replace with real posts later */}
              <span className="cursor-default">{post.title}</span>
            </h2>
            <p className="mt-2 max-w-2xl text-muted">{post.excerpt}</p>
            <p className="mt-3 text-sm text-accent/70">Coming soon</p>
          </article>
        ))}
      </div>
    </div>
  );
}
