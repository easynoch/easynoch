"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, ExternalLink, TrendingUp, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.45 },
  }),
};

const beforeAfterPairs = [
  {
    client: "RoseAura Boutique",
    category: "Beauty / DTC · Klaviyo + Shopify",
    before: {
      label: "Email share of revenue",
      value: "12%",
      note: "Underperforming relative to potential",
    },
    after: {
      label: "Email share of revenue",
      value: "25–30%",
      note: "Consistent contribution after audit + flows + calendar",
    },
    summary:
      "Full Klaviyo audit, prioritised highest-impact fixes, stronger segmentation, optimised core flows, and a consistent campaign calendar with monthly reporting. Partnership ongoing.",
    href: "/work/roseaura-boutique",
    accent: "#7c3aed",
  },
  {
    client: "Baseline account (flows-first)",
    category: "Klaviyo dashboard snapshot",
    before: {
      label: "Attributed revenue (30d)",
      value: "2.75%",
      note: "$2,501 of $91k total · almost 100% from flows",
    },
    after: {
      label: "Focus after audit",
      value: "Campaigns + flows",
      note: "Campaign engine activated alongside retention flows",
    },
    summary:
      "Early state: strong abandoned-cart and welcome flows, but campaigns were not yet driving volume. The path forward was clear — protect deliverability, then scale campaigns on engaged segments.",
    href: null,
    accent: "#ca8a04",
    showBeforeImage: true,
  },
  {
    client: "Revital",
    category: "Health & Supplements · Klaviyo",
    before: {
      label: "Typical industry open rate",
      value: "~20–25%",
      note: "Common benchmark for ecommerce email",
    },
    after: {
      label: "Campaign open rates",
      value: "~50%",
      note: "49–51% on 22k+ recipient sends · 99.5%+ delivery",
    },
    summary:
      "Segmented sends to 30/60/90/180-day engaged cohorts, strong subject lines, and tight list hygiene. Peak single-campaign revenue £3,702 with spam complaints at 0–0.1%.",
    href: "/work/revital-campaigns",
    accent: "#0d9488",
  },
  {
    client: "House of Stallion",
    category: "Fashion · Klaviyo + Shopify · Australia",
    before: {
      label: "Email system",
      value: "From scratch",
      note: "No complete Klaviyo setup for tall women’s fashion",
    },
    after: {
      label: "Client outcome",
      value: "Contract restarted",
      note: "Full flows + height/inseam sign-up · ongoing partnership",
    },
    summary:
      "Built multi-step sign-up (height & inseam), Welcome, Browse Abandonment, Abandoned Cart, Post-Purchase, and VIP re-engagement. Designed in Figma, implemented in Klaviyo, synced from Shopify.",
    href: "/work/house-of-stallion",
    accent: "#1c1917",
  },
  {
    client: "Salon Station The Clinic",
    category: "Beauty clinic · Mailchimp · Australia",
    before: {
      label: "Promo context",
      value: "$1,200",
      note: "Signature Lift treatment full price",
    },
    after: {
      label: "Campaign + system",
      value: "$500 offer",
      note: "Launched to 11,000+ contacts · Welcome + Abandoned Booking live",
    },
    summary:
      "Full Mailchimp foundation (Welcome + Abandoned Booking) plus a promotional campaign and Shopify landing page for the Signature Lift offer. Strong engagement on the first send.",
    href: "/work/salon-station-clinic",
    accent: "#be185d",
  },
];

const campaignHighlights = [
  {
    date: "21 Mar 2025",
    subject: "Fast, Focused & Productive – Your Energy Fix Is Here",
    openRate: "50.49%",
    recipients: "22,587",
    revenue: "£2,333.75",
    delivery: "99.6%",
    image: "/screenshots/revital-campaign-1.png",
  },
  {
    date: "24 Mar 2025",
    subject: "Discover Viridian Supplements",
    openRate: "49.35%",
    recipients: "22,019",
    revenue: "£1,304.69",
    delivery: "99.5%",
    image: "/screenshots/revital-campaign-2.png",
  },
  {
    date: "9 Apr 2025",
    subject: "Sitewide Spring Sale! Up to 20% off!",
    openRate: "50.84%",
    recipients: "22,241",
    revenue: "£3,702.33",
    delivery: "99.8%",
    image: "/screenshots/revital-campaign-3.png",
  },
  {
    date: "20 Apr 2025",
    subject: "Tick Tock – Your Extra £5 Off Ends Soon!",
    openRate: "50.83%",
    recipients: "22,352",
    revenue: "£3,525.23",
    delivery: "99.6%",
    image: "/screenshots/revital-campaign-4.png",
  },
  {
    date: "21 Apr 2025",
    subject: "Supplements That Work Harder Than Your Morning Coffee",
    openRate: "51.12%",
    recipients: "22,448",
    revenue: "£3,123.01",
    delivery: "99.6%",
    image: "/screenshots/revital-campaign-5.png",
  },
];

export default function ResultsPage() {
  return (
    <div>
      {/* Hero */}
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <p className="text-sm font-medium uppercase tracking-widest text-accent">
            Results
          </p>
          <h1 className="mt-2 max-w-3xl text-4xl font-bold tracking-tight md:text-5xl text-balance">
            Before → after from live accounts
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-muted leading-relaxed">
            Revenue share, open rates, deliverability, and client outcomes —
            not mock data. Each pair is tied to real work.
          </p>
        </div>
      </section>

      {/* Before / After pairs */}
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
          <div className="flex items-center gap-2 text-accent">
            <TrendingUp size={18} />
            <p className="text-sm font-semibold uppercase tracking-widest">
              Growth pairs
            </p>
          </div>
          <h2 className="mt-3 text-2xl font-bold tracking-tight md:text-3xl">
            What changed after the work
          </h2>

          <div className="mt-12 space-y-10">
            {beforeAfterPairs.map((pair, i) => (
              <motion.div
                key={pair.client}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                variants={fadeUp}
                className="overflow-hidden rounded-2xl border border-border bg-card"
              >
                <div className="border-b border-border px-6 py-4 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-semibold tracking-tight">{pair.client}</h3>
                    <p className="text-xs text-muted mt-0.5">{pair.category}</p>
                  </div>
                  {pair.href && (
                    <Link
                      href={pair.href}
                      className="inline-flex items-center gap-1 text-xs font-medium text-accent hover:underline"
                    >
                      Case study <ArrowUpRight size={12} />
                    </Link>
                  )}
                </div>

                <div className="grid md:grid-cols-[1fr_auto_1fr] gap-0">
                  {/* Before */}
                  <div className="p-6 border-b md:border-b-0 md:border-r border-border">
                    <span className="inline-block rounded-full bg-zinc-500/15 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-muted">
                      Before
                    </span>
                    <p className="mt-4 text-3xl font-bold tracking-tight text-muted-2">
                      {pair.before.value}
                    </p>
                    <p className="mt-1 text-sm font-medium">{pair.before.label}</p>
                    <p className="mt-1 text-xs text-muted leading-relaxed">
                      {pair.before.note}
                    </p>
                  </div>

                  {/* Arrow */}
                  <div className="hidden md:flex items-center justify-center px-2 text-accent">
                    <ArrowRight size={20} />
                  </div>

                  {/* After */}
                  <div className="p-6 bg-accent/5">
                    <span className="inline-block rounded-full bg-accent/15 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-accent">
                      After
                    </span>
                    <p className="mt-4 text-3xl font-bold tracking-tight text-accent">
                      {pair.after.value}
                    </p>
                    <p className="mt-1 text-sm font-medium">{pair.after.label}</p>
                    <p className="mt-1 text-xs text-muted leading-relaxed">
                      {pair.after.note}
                    </p>
                  </div>
                </div>

                <div className="border-t border-border px-6 py-4">
                  <p className="text-sm text-muted leading-relaxed">{pair.summary}</p>
                </div>

                {/* Optional before dashboard image */}
                {"showBeforeImage" in pair && pair.showBeforeImage && (
                  <div className="border-t border-border">
                    <div className="px-5 py-2.5 flex items-center justify-between bg-background/50">
                      <p className="text-xs text-muted">
                        Baseline dashboard · 2.75% attributed revenue
                      </p>
                      <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-medium text-amber-400">
                        Screenshot
                      </span>
                    </div>
                    <div className="relative aspect-[16/10] w-full bg-zinc-900">
                      <Image
                        src="/screenshots/before-2-75-percent.png"
                        alt="Klaviyo dashboard showing 2.75% attributed revenue before optimization"
                        fill
                        className="object-contain object-top"
                        sizes="(max-width: 1152px) 100vw, 1152px"
                      />
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Campaign deep-dive - Revital */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-20">
        <p className="text-sm font-medium uppercase tracking-widest text-accent">
          Campaign deep-dive
        </p>
        <h2 className="mt-2 text-2xl font-bold tracking-tight md:text-3xl">
          Revital · five campaigns, ~50% opens
        </h2>
        <p className="mt-3 max-w-2xl text-muted leading-relaxed">
          Full Klaviyo reports for each send. Large list, engaged segments,
          consistent deliverability.
        </p>

        <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
          {[
            { value: "~50%", label: "Avg open rate" },
            { value: "99.5%+", label: "Delivery rate" },
            { value: "£3,702", label: "Peak campaign revenue" },
            { value: "0–0.1%", label: "Spam complaint rate" },
          ].map((s) => (
            <div
              key={s.label}
              className="rounded-xl border border-border bg-card px-5 py-4"
            >
              <p className="text-2xl font-bold tracking-tight">{s.value}</p>
              <p className="mt-1 text-sm text-muted">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 space-y-12">
          {campaignHighlights.map((c, i) => (
            <motion.div
              key={c.date}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              variants={fadeUp}
              className="grid gap-6 lg:grid-cols-[1fr_1.2fr] lg:items-start"
            >
              <div>
                <p className="text-xs font-medium text-muted">{c.date}</p>
                <h3 className="mt-1 text-lg font-semibold leading-snug">
                  {c.subject}
                </h3>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  <div className="rounded-lg border border-border bg-card px-3 py-2.5">
                    <p className="text-lg font-bold">{c.openRate}</p>
                    <p className="text-[11px] text-muted">Open rate</p>
                  </div>
                  <div className="rounded-lg border border-border bg-card px-3 py-2.5">
                    <p className="text-lg font-bold">{c.revenue}</p>
                    <p className="text-[11px] text-muted">Revenue</p>
                  </div>
                  <div className="rounded-lg border border-border bg-card px-3 py-2.5">
                    <p className="text-lg font-bold">{c.recipients}</p>
                    <p className="text-[11px] text-muted">Opened (approx)</p>
                  </div>
                  <div className="rounded-lg border border-border bg-card px-3 py-2.5">
                    <p className="text-lg font-bold">{c.delivery}</p>
                    <p className="text-[11px] text-muted">Delivery rate</p>
                  </div>
                </div>
              </div>
              <div className="overflow-hidden rounded-xl border border-border bg-zinc-900">
                <div className="relative aspect-[16/11] w-full">
                  <Image
                    src={c.image}
                    alt={`Klaviyo report: ${c.subject}`}
                    fill
                    className="object-contain object-top"
                    sizes="(max-width: 1024px) 100vw, 55vw"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* More proof */}
      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <h2 className="text-2xl font-bold tracking-tight">More proof</h2>
          <p className="mt-2 text-muted max-w-xl">
            Full folders of campaign reports, flow performance, and client
            metrics are in the shared drive.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href="https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white transition hover:bg-accent-hover"
            >
              Open Metrics Drive <ExternalLink size={14} />
            </a>
            <Link
              href="/work"
              className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold transition hover:border-accent hover:text-accent"
            >
              All projects <ArrowUpRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-16 text-center">
          <h2 className="text-3xl font-bold tracking-tight">
            Want numbers like these on your account?
          </h2>
          <p className="mx-auto mt-3 max-w-md text-muted">
            Audits, flow builds, and campaign support for Shopify / Klaviyo brands.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-8 py-3.5 text-sm font-semibold text-white transition hover:bg-accent-hover"
            >
              Get in touch <ArrowUpRight size={16} />
            </Link>
            <a
              href="https://wa.me/2348131475529"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border px-8 py-3.5 text-sm font-semibold transition hover:border-green-500 hover:text-green-400"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
