"use client";

import { designSamples } from "@/data/projects";
import { ExternalLink, ImageIcon } from "lucide-react";
import { motion } from "framer-motion";
import { ScreenshotPlaceholder } from "@/components/ScreenshotPlaceholder";

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.04, duration: 0.4 },
  }),
};

export default function DesignsPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
      <div className="max-w-2xl">
        <p className="text-sm font-medium uppercase tracking-widest text-accent">
          Email Design
        </p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight md:text-5xl text-balance">
          Figma email designs
        </h1>
        <p className="mt-4 text-lg text-muted leading-relaxed">
          Designs across beauty, fashion, lifestyle, sports, real estate and more.
          Click any card to open the Figma file. Drop PNG/JPG exports into{" "}
          <code className="text-accent text-sm">/public/screenshots/</code> to
          replace placeholders.
        </p>
      </div>

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {designSamples.map((sample, i) => (
          <motion.a
            key={sample.name}
            href={sample.figmaUrl}
            target="_blank"
            rel="noopener noreferrer"
            custom={i}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="group overflow-hidden rounded-2xl border border-border bg-card transition hover:border-accent/40 hover:bg-card-hover"
          >
            {/* Placeholder — replace with real image when available */}
            <div className="relative aspect-[4/3] w-full overflow-hidden">
              <div
                className="absolute inset-0"
                style={{ backgroundColor: sample.color }}
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/20">
                <ImageIcon className="h-6 w-6 text-white/70" />
                <span className="text-xs text-white/60">Screenshot placeholder</span>
              </div>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 transition group-hover:opacity-100 bg-black/40">
                <span className="inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-2 text-sm font-medium text-white backdrop-blur-sm">
                  Open in Figma <ExternalLink size={14} />
                </span>
              </div>
            </div>
            <div className="p-5">
              <p className="text-xs text-muted">{sample.category}</p>
              <h3 className="mt-1 text-lg font-semibold tracking-tight group-hover:text-accent transition-colors">
                {sample.name}
              </h3>
            </div>
          </motion.a>
        ))}
      </div>

      <div className="mt-16 rounded-2xl border border-border bg-card p-8 md:p-10 text-center">
        <p className="text-muted leading-relaxed max-w-lg mx-auto">
          More designs and live campaign metrics (open rates, revenue, flow performance)
          are available in my Google Drive.
        </p>
        <a
          href="https://drive.google.com/drive/folders/1vGFc7um-RvVTW2r1OSKiADRvXWQFK5Cw?usp=drive_link"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-accent hover:underline"
        >
          Open Metrics & Results Drive <ExternalLink size={14} />
        </a>
      </div>
    </div>
  );
}
